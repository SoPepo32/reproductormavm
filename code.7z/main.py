#librerias
from tkinter import filedialog
from tkinter import messagebox
from PIL import Image, ImageTk
from pymkv import MKVFile
import tkinter as tk
import subprocess
import argparse
import shutil
import time
import json
import vlc
import os

#scripts para otros procesos
import menus
from mavm import MaVM

shutil.rmtree(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp'))   # Borra la carpeta completa
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp'))

shutil.rmtree(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp_frames'))   # Borra la carpeta completa
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'temp_frames'))

class ventana:
    def __init__(self, ventana_tk, file):
        #ventana
        self.ventana_tk = ventana_tk
        self.ventana_tk.title("reproductor MaVM")
        self.ventana_tk.geometry("800x450")
        self.ventana_tk.minsize(800,450)
        self.ventana_tk.config(bg='gray')


        #variables
        self.file = file
        self.raiz_proyecto = os.path.dirname(os.path.abspath(__file__))
        print(self.raiz_proyecto)
        self.carpeta_temporal = os.path.join(self.raiz_proyecto, 'temp')
        self.carpeta_temporal_frames = os.path.join(self.raiz_proyecto, 'temp_frames')


        #objetos
        #abrir un archivo
        archivos = tk.Button(self.ventana_tk, text="archivos", command=self.archivos_ventana)
        archivos.place(x=0,y=0,width=80,height=16)

        self.reproductor = tk.Frame(self.ventana_tk, bg='black')
        self.reproductor.place(x=0,y=20)

        self.atras_boton = tk.Button(self.ventana_tk, text="<-10s")
        self.atras_boton.place(x=0,y=430,width=20,height=16)

        self.adelante_boton = tk.Button(self.ventana_tk, text="10s->")
        self.adelante_boton.place(x=780,y=430,width=20,height=16)

        self.play_boton = tk.Button(self.ventana_tk, text="play/pause")
        self.play_boton.place(x=780,y=430,width=20,height=16)

        self.ventana_tk.after(50, self.actalizar_medidas)


        #codigo
        if self.file:
            self.repdorucir()
    
    def archivos_ventana(self):
        self.file = filedialog.askopenfilename(title='buscar video MaVM', filetypes=(('video MaVM', '*.mavm'),
                                                                                     ('todos los archivos', '*.*')))
        print(self.file)
        self.repdorucir()

    def actalizar_medidas(self):
        ancho_ventana = self.ventana_tk.winfo_width()
        alto_ventana = self.ventana_tk.winfo_height()
        
        interfaz_alto = max(self.ventana_tk.winfo_height()*.05,16)
        interfaz_ancho = max(self.ventana_tk.winfo_width()*.0625,50)
        play_ancho = max(self.ventana_tk.winfo_width()*.1875,150)

        self.reproductor.config(width=ancho_ventana,height=alto_ventana-(20+4+interfaz_alto))

        self.atras_boton.place(x=int(ancho_ventana/3)-interfaz_ancho/2,y=alto_ventana-interfaz_alto,width=interfaz_ancho,height=interfaz_alto)

        self.play_boton.place(x=int(ancho_ventana/2)-play_ancho/2,y=alto_ventana-interfaz_alto,width=play_ancho,height=interfaz_alto)

        self.adelante_boton.place(x=int(2*ancho_ventana/3)-interfaz_ancho/2,y=alto_ventana-interfaz_alto,width=interfaz_ancho,height=interfaz_alto)

        self.ventana_tk.after(10, self.actalizar_medidas)

    def start(self, contenidos):
        for widget in self.reproductor.winfo_children():
            widget.destroy()  #elimina cada widget
        
        print(contenidos)
        
        metadata_path   = ''
        start_menu_path = ''
        for contenido in contenidos:
            if contenido['title'] == 'metadata.json':
                metadata_path = contenido['path']
            elif contenido['title'] == 'start.json':
                start_menu_path = contenido['path']
        
        metadata_file = open(metadata_path, 'r')
        metadata_text = metadata_file.read()
        metadata_json = json.loads(metadata_text)
        metadata_file.close()

        start_menu_file = open(start_menu_path, 'r')
        start_menu_text = start_menu_file.read()
        start_menu_json = json.loads(start_menu_text)
        start_menu_file.close()

        self.video_mavm_version = metadata_json["mavm_version"]
        if not(self.video_mavm_version in ['v.2.1.0']):
            messagebox.showerror("error de version de archivo", "la version de archivo no es compatible. Este programa solo soporta la v.2.1.0")
            exit()
        print(self.video_mavm_version)

        version_compatible = menus.version_formato(self.video_mavm_version)[0]
        print(version_compatible)

        descripcion = tk.Label(self.reproductor,text=metadata_json["descripcion"]["text"],fg="#ffffff",background="black")
        descripcion.place(x=self.reproductor.winfo_width()//2-4*len(metadata_json["descripcion"]["text"]),y=self.reproductor.winfo_height()//2)
        self.reproductor.update_idletasks()
        print(metadata_json["descripcion"]["text"])

        for i in range(1,metadata_json["descripcion"]["duration"]*100):
            time.sleep(1/100)

        self.menu(start_menu_json)

    def menu(self, menu_json):
        for widget in self.reproductor.winfo_children():
            widget.destroy()  #elimina cada widget
        
        menu_dat = menus.version_formato(self.video_mavm_version)
        lista_comandos = menu_dat[1](menu_json).lista_comandos
        print(lista_comandos)

    def repdorucir(self):
        videos = MaVM.extrac_type_all(file=self.file, output_folder=self.carpeta_temporal, content_type=None)
        #videos = MaVM.extrac_type_all(file=self.file, output_folder=self.carpeta_temporal, content_type="video/x-matroska")

        contenido_dat = []
        for video in videos:
            directorio, archivo = os.path.split(video)
            contenido_dat.append({'title':archivo, 'path':video})
            print(archivo)
        self.start(contenido_dat)

    def video(self,video_path):
        subprocess.run(['mpv', video_path])

def args():
    parser = argparse.ArgumentParser(description="reproductor MaVM")
    parser.add_argument("file", nargs='?', help="ruta del video .mavm")
    
    args_var = parser.parse_args()
    
    if args_var.file:
        if not('.mavm' in args_var.file.lower()):
            print("el archivo debe ser .mavm")
            exit()
        elif not(os.path.exists(args_var.file)):
            print("el archivo no existe")
            exit()
        else:
            file = os.path.abspath(args_var.file)
            ventana_tk = tk.Tk()
            ventana(ventana_tk=ventana_tk, file=file)
            ventana_tk.mainloop()
    else:
        ventana_tk = tk.Tk()
        ventana(ventana_tk, None)
        ventana_tk.mainloop()

args()